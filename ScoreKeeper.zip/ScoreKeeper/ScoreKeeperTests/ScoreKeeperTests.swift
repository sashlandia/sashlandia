//
//  ScoreKeeperTests.swift
//  ScoreKeeperTests
//
//  Created by Sasha on 15.11.2025.
//

import Testing
@testable import ScoreKeeper

struct ScoreKeeperTests {
    
    @Test("Reset player scores", arguments: [0, 10, 20])
    func reset(to newValue: Int) async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        var scoreboard = Scoreboard(players: [
            Player(name: "Elisha", score: 0),
            Player(name: "Andre", score: 5),
        ])
        scoreboard.resetScore(to: newValue)
        
        for player in scoreboard.players {
            #expect(player.score == newValue)
        }
    }
    
    @Test("Highest score wins")
    func highestScoreWins() {
        let scoreboard = Scoreboard(
            players: [
                Player(name: "Саша", score: 4),
                Player(name: "Коля", score: 0),
            ],
            state: .gameOver,
            doesHighestScoreWins: true
        )
        let winners = scoreboard.winners
        #expect(winners == [Player(name: "Саша", score: 4)])
    }
    
    @Test("Lowest score wins")
    func lowestScoreWins(){
        let scoreboard = Scoreboard(
            players: [
                Player(name: "Elisha", score: 0),
                Player(name: "Andre", score: 4),
            ],
            state: .gameOver,
            doesHighestScoreWins: false
        )
        let winners = scoreboard.winners
        #expect(winners == [Player(name: "Elisha", score: 0)])

    }
}
