//
//  ContentView.swift
//  ScoreKeeper
//
//  Created by Sasha on 12.11.2025.
//

import SwiftUI

struct ContentView: View {
    
    @State private var scoreboard = Scoreboard()
    @State private var startingPoints = 0
    
    var body: some View {
        VStack(alignment: .leading){
            Text("Счетчик очков")
                .font(.title)
                .bold()
                .padding(.bottom)
            
            SettingsView(startingPoints: $startingPoints)
            
            Grid{
                GridRow{
                    Text("Игрок")
                        .gridColumnAlignment(.leading)
                    Text("Очки")
                }
                .font(.headline)
                
                ForEach($scoreboard.players) { $player in
                    GridRow{
                        TextField("Имя", text: $player.name)
                        Text("\(player.score)")
                        Stepper("\(player.score)", value: $player.score)
                            .labelsHidden()
                    }
                }
            }
            .padding(.vertical)
            
            Button("Добавить игрока", systemImage: "plus") {
                scoreboard.players.append(Player(name: "", score: 0))
            }
            Spacer()
            
            switch scoreboard.state {
            case .setup:
                Button("Начать игру", systemImage: "play.fill"){
                    scoreboard.state = .playing
                    scoreboard.resetScore(to: startingPoints)
                }
            case .playing:
                Button("Закончить игру", systemImage: "stop.fill"){
                    scoreboard.state = .gameOver
                }
            case .gameOver:
                Button("Начать заново", systemImage: "arrow.counterclockwise"){
                    scoreboard.state = .setup
                }
            }
    
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

