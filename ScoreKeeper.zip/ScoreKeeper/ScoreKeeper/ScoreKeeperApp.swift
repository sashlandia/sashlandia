//
//  ScoreKeeperApp.swift
//  ScoreKeeper
//
//  Created by Sasha on 12.11.2025.
//

import SwiftUI

@main
struct ScoreKeeperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
