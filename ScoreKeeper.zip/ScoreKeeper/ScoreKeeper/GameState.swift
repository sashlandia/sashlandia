//
//  GameState.swift
//  ScoreKeeper
//
//  Created by Sasha on 15.11.2025.
//

import Foundation

enum GameState {
    case setup
    case playing
    case gameOver
}
