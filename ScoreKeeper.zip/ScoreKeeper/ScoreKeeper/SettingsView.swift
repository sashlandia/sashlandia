//
//  SettingsView.swift
//  ScoreKeeper
//
//  Created by Sasha on 15.11.2025.
//

import SwiftUI

struct SettingsView: View {
    
    @Binding var startingPoints: Int
    
    var body: some View {
        VStack(alignment: .leading){
            Text("Правила игры")
            Divider()
            Picker("Начальные очки", selection: $startingPoints) {
                Text("0 начальных очков")
                    .tag(0)
                Text("10 начальных очков")
                    .tag(10)
                Text("20 начальных очков")
                    .tag(20)
            }
        }
        .padding()
        .background(.thinMaterial, in: .rect(cornerRadius: 10.0))
    }
}

#Preview {
    @Previewable @State var startingPoints = 10
    SettingsView(startingPoints: $startingPoints)
}
