//
//  ContentView.swift
//  DiceRoller
//
//  Created by Sasha on 08.11.2025.
//

import SwiftUI

struct ContentView: View {
    
    @State var numberOfDice = 1
    
    var body: some View {
        VStack {
            Text("Dice Roller")
                .font(.largeTitle.lowercaseSmallCaps())
                .foregroundStyle(.white)
            
            HStack {
                ForEach(1...numberOfDice, id: \.description) { _ in
                    DiceView()
                }
            }
            
            HStack{
                Button("Убрать куб", systemImage: "minus.circle.fill") {
                    withAnimation{
                        numberOfDice -= 1
                    }
                }
                .disabled(numberOfDice == 1)

                Button("Добавить куб", systemImage: "plus.circle.fill") {
                    withAnimation{
                        numberOfDice += 1
                    }
                }
                .disabled(numberOfDice == 5)
            }
            .labelStyle(.iconOnly)
            .font(.title)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.appBackground)
        .tint(.white)

    }
}

#Preview {
    ContentView()
}
