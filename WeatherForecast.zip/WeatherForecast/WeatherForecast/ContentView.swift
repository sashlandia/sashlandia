//
//  ContentView.swift
//  WeatherForecast
//
//  Created by Sasha on 04.11.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView(.horizontal){
            HStack{
                DayForecast(day: "Понедельник", high: +35, low: +20, isRainy: false)
                DayForecast(day: "Вторник", high: +40, low: +25, isRainy: false)
                DayForecast(day: "Среда", high: +30, low: +25, isRainy: true)
                DayForecast(day: "Четверг", high: +17, low: +15, isRainy: true)
                DayForecast(day: "Пятница", high: +37, low: +26, isRainy: true)
                DayForecast(day: "Суббота", high: +33, low: +20, isRainy: false)
                DayForecast(day: "Воскресенье", high: +55, low: +35, isRainy: false)
            }
        }
    }
}

#Preview {
    ContentView()
}

struct DayForecast: View {
    
    let day: String
    let high: Int
    let low: Int
    let isRainy: Bool
    
    var iconName: String {
        if isRainy {
            return "cloud.rain.fill"
        } else {
            return "sun.max.fill"
        }
    }
    
    var iconColor: Color {
        if isRainy {
            return Color.blue
        } else {
            return Color.yellow
        }
    }
    
    
    var body: some View {
        VStack {
            Text(day)
                .font(Font.headline)
            Image(systemName: iconName)
                .foregroundStyle(iconColor)
                .font(Font.largeTitle)
                .padding(5)
            Text("Высокая t: \(high) Cº")
                .fontWeight(Font.Weight.semibold)
            Text("Низкая t: \(low) Cº")
                .fontWeight(Font.Weight.medium)
                .foregroundStyle(Color.secondary)
        }
        .padding()
    }
}
