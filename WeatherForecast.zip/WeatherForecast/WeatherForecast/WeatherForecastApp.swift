//
//  WeatherForecastApp.swift
//  WeatherForecast
//
//  Created by Sasha on 04.11.2025.
//

import SwiftUI

@main
struct WeatherForecastApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
