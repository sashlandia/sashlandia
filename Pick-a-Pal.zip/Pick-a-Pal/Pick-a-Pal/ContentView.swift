//
//  ContentView.swift
//  Pick-a-Pal
//
//  Created by Sasha on 11.11.2025.
//

import SwiftUI

struct ContentView: View {
    
    @State private var names: [String] = []
    @State private var nameToAdd = ""
    @State private var pickedName = ""
    @State private var shouldRemovePickedName = false
    @State private var savedNames: [String] = []
    
    var body: some View {
        VStack {
            VStack{
                Image(systemName: "person.3.sequence.fill")
                    .foregroundStyle(.orange)
                    .symbolRenderingMode(.hierarchical)
                Text("Pick-a-Pal")
            }
            .font(.title)
            .bold()
            
            Text(pickedName.isEmpty ? " " : "Удалился - \(pickedName)")
                .font(.title2)
                .bold()
                .foregroundStyle(.orange)
            
            List{
                ForEach(names, id: \.description) { name in
                    Text(name)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 8))

            TextField("Добавить", text: $nameToAdd)
                .autocorrectionDisabled()
                .onSubmit {
                    // Сначала обрезаем пробелы
                    let trimmedName = nameToAdd.trimmingCharacters(in: .whitespacesAndNewlines)

                    // Проверяем уникальность уже для обрезанной строки
                    if !trimmedName.isEmpty && !names.contains(trimmedName) {
                        names.append(trimmedName)
                    }
                    // Очищаем поле
                    nameToAdd = ""
                }
            Divider()
            
            Toggle("Удалить после выбора", isOn: $shouldRemovePickedName)
            Button {
                if let randomName = names.randomElement() {
                    pickedName = randomName


                    if shouldRemovePickedName {
                        names.removeAll { name in
                            return (name == randomName)
                        }
                    }
                } else {
                    pickedName = ""
                }
            } label: {
                Text("Выбери случайное имя")
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
            }
            .buttonStyle(.borderedProminent)
            .tint(.orange)
            .font(.title2)
            
            HStack{
                Button {
// Сохранение
                    savedNames = names
                } label: {
                    Text("Сохранить таблицу")
                        .padding(.vertical, 8)
                        .padding(.horizontal, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(.orange)
                .font(.title2)
                
                Button {
// Загрузка
                    if !savedNames.isEmpty {
                        names = savedNames
                    }
                } label: {
                    Text("Загрузить таблицу")
                        .padding(.vertical, 8)
                        .padding(.horizontal, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(.orange)
                .font(.title2)
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
