//
//  Pick_a_PalApp.swift
//  Pick-a-Pal
//
//  Created by Sasha on 11.11.2025.
//

import SwiftUI

@main
struct Pick_a_PalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
